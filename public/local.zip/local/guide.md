# Hướng dẫn Cài đặt & Vận hành Hệ thống - Skyqueen Logistics System

Tài liệu này hướng dẫn chi tiết cách thiết lập và khởi chạy toàn bộ hệ thống Skyqueen Logistics trên máy tính cá nhân của bạn từ tệp tin nén giải nén.

---

## 1. Yêu cầu hệ thống trước khi cài đặt

Đảm bảo máy tính của bạn đã được cài đặt và kích hoạt dịch vụ **Docker** hoặc **Docker Desktop**:
- **Windows / macOS**: Tải và cài đặt [Docker Desktop](https://www.docker.com/products/docker-desktop/).
- **Linux**: Cài đặt gói `docker` và `docker-compose-plugin`.
- Đảm bảo ứng dụng Docker đang được mở và hoạt động bình thường.

---

## 2. Các bước triển khai chi tiết (Step-by-Step)

### Bước 1: Giải nén thư mục cài đặt
Giải nén tệp tin `local.zip` mà bạn nhận được vào một thư mục làm việc trên máy tính (ví dụ: `/opt/skyqueen-system` trên Linux/macOS hoặc một thư mục bất kỳ trên Windows).

Cấu trúc thư mục sau khi giải nén sẽ như sau:
```text
local/
├── docker-compose.yml   # File điều phối hệ thống
├── .env.docker          # File cấu hình môi trường mẫu
├── guide.md             # Hướng dẫn này
└── db/
    └── init/
        └── backup_skyqueen-migration-20260613-233555.sql  # Dữ liệu ban đầu
```

### Bước 2: Đăng nhập vào Registry để lấy quyền tải ứng dụng
Mở Terminal (hoặc PowerShell / Command Prompt trên Windows) và di chuyển vào thư mục `local` vừa giải nén. 

Chạy lệnh dưới đây để đăng nhập vào máy chủ lưu trữ gói phần mềm (GitHub Container Registry):
```bash
echo "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" | docker login ghcr.io -u quangtuandev --password-stdin
```
*Nếu màn hình hiển thị thông báo `Login Succeeded` là bạn đã đăng nhập thành công.*

### Bước 3: Cấu hình tệp tin môi trường `.env`
1. Thực hiện sao chép file cấu hình mẫu `.env.docker` thành file mới tên là `.env`:
   - **Linux/macOS**: `cp .env.docker .env`
   - **Windows**: Copy file `.env.docker` và đổi tên thành `.env`
2. Mở file `.env` bằng công cụ soạn thảo văn bản (Notepad, VS Code, v.v.).
3. Kiểm tra và điền mã kết nối Cloudflare Tunnel của bạn vào dòng:
   `TUNNEL_TOKEN=mã_token_cloudflare_của_bạn`
4. Cấu hình lại các cổng kết nối máy chủ nếu bị trùng (mặc định Backend chạy cổng `3002`, Frontend chạy cổng `3003`).

### Bước 4: Khởi chạy hệ thống
Tại thư mục `local` chứa file `docker-compose.yml` và file `.env` vừa cấu hình, thực thi lệnh sau:
```bash
docker compose up -d
```
*Lưu ý:*
- Lệnh này sẽ tự động kết nối và tải các image đóng gói sẵn từ GitHub về máy của bạn.
- Trong lần chạy đầu tiên, MySQL sẽ tự động quét thư mục `db/init/` và nhập (import) toàn bộ dữ liệu từ tệp tin SQL có sẵn vào cơ sở dữ liệu. Quá trình này có thể mất từ 1 - 2 phút.

---

## 3. Quản lý & Giám sát Hệ thống

### A. Kiểm tra trạng thái các dịch vụ
```bash
docker compose ps
```
Nếu toàn bộ các dịch vụ hiển thị trạng thái `Running` hoặc `Up (healthy)` là hệ thống đã hoạt động bình thường.

### B. Xem Logs hoạt động của hệ thống
- Xem log toàn bộ hệ thống:
  ```bash
  docker compose logs -f
  ```
- Xem log của riêng dịch vụ Backend:
  ```bash
  docker compose logs -f backend
  ```
- Xem log của riêng dịch vụ Frontend:
  ```bash
  docker compose logs -f frontend
  ```

### C. Dừng hệ thống
Để tạm dừng tất cả dịch vụ (dữ liệu của bạn vẫn được lưu trữ an toàn trong ổ cứng):
```bash
docker compose down
```

---

## 4. Cơ chế tự động cập nhật phần mềm (Watchtower)
Hệ thống đã được cài đặt sẵn dịch vụ **Watchtower** (`skyqueen_watchtower`).
- Dịch vụ này chạy nền và sẽ tự động quét sau mỗi **5 phút** để kiểm tra xem lập trình viên có đẩy phiên bản sửa lỗi mới lên hệ thống không.
- Nếu có phiên bản mới, Watchtower sẽ tự động tải về và khởi động lại dịch vụ tương ứng mà bạn không cần gõ bất cứ dòng lệnh nào.
